# Data placement

## CUAD

`scripts/prepare_cuad.py` retrieves `theatticusproject/cuad-qa`, derives the contract identifier, creates contract-grouped partitions, and writes manifests to `data/processed/manifests/`.

No CUAD text is committed to this repository. Users must comply with the dataset license and source terms.

## IFRS 16 disclosure table

Place the public result sheet described by Tumpach et al. at:

```text
data/raw/ifrs16_result.csv
```

The analysis code expects the encoded fields A1-D6 and preserves missing disclosure states as `unknown`.

## External enterprise validation

Raw enterprise contracts are excluded. A de-identified CSV may be supplied at:

```text
data/raw/external_validation.csv
```

The required columns and allowed D1-D6 states are defined in `reproducibility/schema/external_validation.schema.json`. The external file is never used to select the model, fit the answerability threshold, or fit probability calibration.

