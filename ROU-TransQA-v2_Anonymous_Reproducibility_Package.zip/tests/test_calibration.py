import sys
import unittest
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from rou_transqa.calibration import brier_score, expected_calibration_error, fit_temperature, sigmoid


class CalibrationTests(unittest.TestCase):
    def test_calibration_functions(self):
        logits = np.asarray([3.0, 1.0, -1.0, -3.0])
        labels = np.asarray([1, 1, 0, 0])
        temperature = fit_temperature(logits, labels)
        self.assertGreater(temperature, 0)
        probabilities = sigmoid(logits / temperature)
        self.assertLess(brier_score(probabilities, labels), 0.25)
        self.assertGreaterEqual(expected_calibration_error(probabilities, labels, bins=2), 0.0)


if __name__ == "__main__":
    unittest.main()

