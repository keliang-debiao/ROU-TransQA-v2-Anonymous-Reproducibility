import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from rou_transqa.metrics import answerability_metrics, normalize_answer, qa_metrics, token_f1


class MetricTests(unittest.TestCase):
    def test_normalization(self):
        self.assertEqual(normalize_answer("The Governing-Law."), "governinglaw")

    def test_empty_answer_scoring(self):
        self.assertEqual(token_f1("", ""), 1.0)
        self.assertEqual(token_f1("clause", ""), 0.0)

    def test_subset_metrics(self):
        rows = [
            {"prediction": "governing law", "gold_answers": ["governing law"]},
            {"prediction": "", "gold_answers": [""]},
            {"prediction": "", "gold_answers": ["renewal option"]},
            {"prediction": "wrong", "gold_answers": [""]},
        ]
        result = qa_metrics(rows)
        self.assertEqual(result["count"], 4)
        self.assertAlmostEqual(result["has_answer_f1"], 50.0)
        self.assertAlmostEqual(result["no_answer_f1"], 50.0)
        self.assertAlmostEqual(result["macro_qa_f1"], 50.0)

    def test_answerability_confusion(self):
        rows = [
            {"gold_answers": ["clause"], "answerability_probability": 0.8},
            {"gold_answers": [""], "answerability_probability": 0.2},
            {"gold_answers": ["clause"], "answerability_probability": 0.1},
            {"gold_answers": [""], "answerability_probability": 0.9},
        ]
        result = answerability_metrics(rows, 0.5)
        self.assertEqual(result["tp"], 1)
        self.assertEqual(result["tn"], 1)
        self.assertEqual(result["fp"], 1)
        self.assertEqual(result["fn"], 1)


if __name__ == "__main__":
    unittest.main()

