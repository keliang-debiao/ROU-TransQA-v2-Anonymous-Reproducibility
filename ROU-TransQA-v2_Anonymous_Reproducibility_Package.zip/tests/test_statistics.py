import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from rou_transqa.metrics import qa_metrics
from rou_transqa.statistics import holm_adjust, paired_bootstrap


class StatisticalTests(unittest.TestCase):
    def test_holm_is_monotone_in_sorted_order(self):
        adjusted = holm_adjust([0.01, 0.04, 0.03])
        self.assertEqual(len(adjusted), 3)
        self.assertTrue(all(0 <= value <= 1 for value in adjusted))
        self.assertAlmostEqual(adjusted[0], 0.03)

    def test_paired_bootstrap_alignment(self):
        system_a = [
            {"qa_id": "a", "prediction": "x", "gold_answers": ["x"]},
            {"qa_id": "b", "prediction": "", "gold_answers": [""]},
        ]
        system_b = [
            {"qa_id": "a", "prediction": "", "gold_answers": ["x"]},
            {"qa_id": "b", "prediction": "wrong", "gold_answers": [""]},
        ]
        result = paired_bootstrap(
            system_a,
            system_b,
            lambda rows: float(qa_metrics(rows)["overall_f1"]),
            resamples=200,
            seed=7,
        )
        self.assertGreater(result["observed_difference"], 0)


if __name__ == "__main__":
    unittest.main()

