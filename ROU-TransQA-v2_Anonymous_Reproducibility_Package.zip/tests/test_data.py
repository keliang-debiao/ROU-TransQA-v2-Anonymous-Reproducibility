import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from rou_transqa.data import QARecord, contract_grouped_split, split_records


class DataTests(unittest.TestCase):
    def test_contracts_never_cross_splits(self):
        records = []
        for contract_index in range(10):
            for qa_index in range(3):
                records.append(
                    QARecord(
                        qa_id=f"q_{contract_index}_{qa_index}",
                        contract_id=f"c_{contract_index}",
                        question="question",
                        context="context",
                        answers=("answer",) if qa_index == 0 else (),
                        answer_starts=(0,) if qa_index == 0 else (),
                    )
                )
        assignment = contract_grouped_split(
            records,
            seed=42,
            target_contracts={"train": 6, "validation": 2, "test": 2},
        )
        split = split_records(records, assignment)
        sets = [{row.contract_id for row in split[name]} for name in ("train", "validation", "test")]
        self.assertFalse(sets[0] & sets[1])
        self.assertFalse(sets[0] & sets[2])
        self.assertFalse(sets[1] & sets[2])


if __name__ == "__main__":
    unittest.main()

