import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from rou_transqa.mapping import map_d1_d6


class MappingTests(unittest.TestCase):
    def test_full_rou_mapping(self):
        result = map_d1_d6(
            {
                "lease_identification": "This agreement conveys the right to use an identified asset.",
                "lease_term": "The lease term is 36 months.",
                "low_value": "The leased asset has a material value.",
                "renewal": "The lessee may renew the lease for two additional years.",
                "variable_payment": "Variable rent is linked to annual sales.",
                "discount_rate": "The incremental borrowing rate is 5 percent.",
            }
        )
        self.assertEqual(result.D1, "yes")
        self.assertEqual(result.D2, "no")
        self.assertEqual(result.D3, "no")
        self.assertEqual(result.D4, "yes")
        self.assertEqual(result.D5, "yes")
        self.assertEqual(result.D6, "yes")

    def test_short_term_exemption(self):
        result = map_d1_d6(
            {
                "lease_identification": "The contract contains a lease of an identified asset.",
                "lease_term": "The lease term is 10 months and there is no renewal option.",
                "low_value": "The asset has a material value.",
            }
        )
        self.assertEqual(result.D1, "no")
        self.assertEqual(result.D2, "yes")

    def test_unknown_is_preserved(self):
        result = map_d1_d6({})
        self.assertEqual({result.D1, result.D2, result.D3, result.D4, result.D5, result.D6}, {"unknown"})


if __name__ == "__main__":
    unittest.main()

