"""ROU-TransQA-v2 research software."""

__version__ = "1.0.0"

