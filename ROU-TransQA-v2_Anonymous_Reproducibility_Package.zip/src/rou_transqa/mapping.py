from __future__ import annotations

import re
from dataclasses import dataclass


VALID_STATES = {"yes", "no", "unknown"}


@dataclass(frozen=True)
class MappingResult:
    D1: str
    D2: str
    D3: str
    D4: str
    D5: str
    D6: str
    trace: dict[str, list[str]]


def _text(evidence: dict[str, str], keys: tuple[str, ...]) -> str:
    return " ".join(str(evidence.get(key, "")) for key in keys).strip().lower()


def _contains(text: str, patterns: tuple[str, ...]) -> bool:
    return any(re.search(pattern, text, flags=re.IGNORECASE) for pattern in patterns)


def _explicit_negation(text: str, terms: tuple[str, ...]) -> bool:
    for term in terms:
        if re.search(rf"\b(?:no|not|without|does not|shall not)\b[^.;]{{0,45}}\b{term}\b", text):
            return True
    return False


def _lease_term_months(text: str) -> int | None:
    month_match = re.search(r"\b(\d{1,3})\s*(?:calendar\s+)?months?\b", text)
    if month_match:
        return int(month_match.group(1))
    year_match = re.search(r"\b(\d{1,2})\s*years?\b", text)
    if year_match:
        return 12 * int(year_match.group(1))
    return None


def map_d1_d6(evidence: dict[str, str], low_value_threshold: float | None = None) -> MappingResult:
    lease_text = _text(evidence, ("lease_identification", "asset", "scope"))
    term_text = _text(evidence, ("lease_term", "renewal", "purchase_option"))
    low_value_text = _text(evidence, ("low_value", "asset", "amount"))
    renewal_text = _text(evidence, ("renewal", "extension", "lease_term"))
    variable_text = _text(evidence, ("variable_payment", "payment", "rent"))
    rate_text = _text(evidence, ("discount_rate", "interest_rate", "incremental_borrowing_rate"))

    trace: dict[str, list[str]] = {f"D{index}": [] for index in range(1, 7)}

    lease_positive = _contains(lease_text, (r"\blease\b", r"right[- ]of[- ]use", r"identified asset"))
    term_months = _lease_term_months(term_text)
    purchase_or_extended = _contains(
        term_text,
        (r"purchase option", r"reasonably certain.{0,50}(?:renew|extend)", r"renewal.{0,40}longer"),
    ) and not _explicit_negation(term_text, ("purchase", "renewal", "extension"))
    if term_months is None:
        d2 = "unknown" if not term_text else "no"
    elif term_months <= 12 and not purchase_or_extended:
        d2 = "yes"
        trace["D2"].append(f"lease_term_months={term_months}")
    else:
        d2 = "no"
        trace["D2"].append(f"lease_term_months={term_months}")

    low_value_positive = _contains(
        low_value_text,
        (r"low[- ]value", r"minor value", r"immaterial value", r"small[- ]ticket"),
    ) and not _explicit_negation(low_value_text, ("low-value", "low value"))
    amount_match = re.search(r"(?:usd|\$|eur|gbp)\s*([0-9][0-9,]*(?:\.\d+)?)", low_value_text)
    if amount_match and low_value_threshold is not None:
        amount = float(amount_match.group(1).replace(",", ""))
        low_value_positive = low_value_positive or amount <= low_value_threshold
        trace["D3"].append(f"amount={amount}")
    if low_value_positive:
        d3 = "yes"
    elif low_value_text:
        d3 = "no"
    else:
        d3 = "unknown"

    renewal_terms = ("renewal", "extension", "continuation")
    renewal_positive = _contains(
        renewal_text,
        (r"\brenew(?:al|ed|s)?\b", r"\bextend(?:ed|s|ing)?\b", r"reasonably certain.{0,60}continue"),
    ) and not _explicit_negation(renewal_text, renewal_terms)
    if renewal_positive:
        d4 = "yes"
    elif renewal_text:
        d4 = "no"
    else:
        d4 = "unknown"

    variable_terms = ("variable", "percentage", "index-linked", "sales-linked")
    variable_positive = _contains(
        variable_text,
        (r"variable (?:lease )?(?:payment|rent)", r"percentage rent", r"index[- ]linked", r"sales[- ]linked"),
    ) and not _explicit_negation(variable_text, variable_terms)
    if variable_positive:
        d5 = "yes"
    elif variable_text:
        d5 = "no"
    else:
        d5 = "unknown"

    rate_terms = ("discount rate", "incremental borrowing rate", "implicit rate", "interest rate")
    rate_positive = _contains(
        rate_text,
        (r"discount rate", r"incremental borrowing rate", r"rate implicit", r"interest rate"),
    ) and not _explicit_negation(rate_text, rate_terms)
    if rate_positive:
        d6 = "yes"
    elif rate_text:
        d6 = "no"
    else:
        d6 = "unknown"

    if lease_positive and d2 == "no" and d3 == "no":
        d1 = "yes"
        trace["D1"].append("lease_positive_and_no_exemption")
    elif d2 == "yes" or d3 == "yes":
        d1 = "no"
        trace["D1"].append("exemption_detected")
    elif lease_text or term_text or low_value_text:
        d1 = "unknown"
        trace["D1"].append("incomplete_recognition_evidence")
    else:
        d1 = "unknown"
        trace["D1"].append("no_retained_evidence")

    values = {"D1": d1, "D2": d2, "D3": d3, "D4": d4, "D5": d5, "D6": d6}
    if any(value not in VALID_STATES for value in values.values()):
        raise AssertionError("Unexpected indicator state")
    for indicator, value in values.items():
        trace[indicator].append(f"state={value}")
    return MappingResult(**values, trace=trace)

