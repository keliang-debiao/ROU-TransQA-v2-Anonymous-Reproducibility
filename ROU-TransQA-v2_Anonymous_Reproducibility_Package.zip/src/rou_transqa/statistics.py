from __future__ import annotations

from collections.abc import Callable

import numpy as np


def paired_bootstrap(
    system_a: list[dict],
    system_b: list[dict],
    metric: Callable[[list[dict]], float],
    resamples: int = 10_000,
    seed: int = 2025,
    confidence_level: float = 0.95,
) -> dict[str, float | int | list[float]]:
    if len(system_a) != len(system_b):
        raise ValueError("Paired systems must contain the same number of rows")
    ids_a = [row["qa_id"] for row in system_a]
    ids_b = [row["qa_id"] for row in system_b]
    if ids_a != ids_b:
        raise ValueError("Paired systems must have identical QA order")
    rng = np.random.default_rng(seed)
    n_rows = len(system_a)
    differences = np.empty(resamples, dtype=float)
    for index in range(resamples):
        selection = rng.integers(0, n_rows, size=n_rows)
        rows_a = [system_a[position] for position in selection]
        rows_b = [system_b[position] for position in selection]
        differences[index] = metric(rows_a) - metric(rows_b)
    alpha = 1.0 - confidence_level
    lower, upper = np.quantile(differences, [alpha / 2.0, 1.0 - alpha / 2.0])
    p_value = 2.0 * min(float(np.mean(differences <= 0)), float(np.mean(differences >= 0)))
    observed = metric(system_a) - metric(system_b)
    return {
        "resamples": resamples,
        "seed": seed,
        "observed_difference": float(observed),
        "confidence_interval": [float(lower), float(upper)],
        "two_sided_p": min(1.0, p_value),
    }


def holm_adjust(p_values: list[float]) -> list[float]:
    count = len(p_values)
    order = np.argsort(p_values)
    adjusted = np.zeros(count, dtype=float)
    running = 0.0
    for rank, original_index in enumerate(order):
        candidate = (count - rank) * float(p_values[original_index])
        running = max(running, candidate)
        adjusted[original_index] = min(1.0, running)
    return adjusted.tolist()


def t_confidence_interval(values: list[float], confidence_level: float = 0.95) -> tuple[float, float]:
    from scipy.stats import t

    array = np.asarray(values, dtype=float)
    if len(array) < 2:
        raise ValueError("At least two values are required")
    mean = float(array.mean())
    standard_error = float(array.std(ddof=1) / np.sqrt(len(array)))
    critical = float(t.ppf((1.0 + confidence_level) / 2.0, df=len(array) - 1))
    return mean - critical * standard_error, mean + critical * standard_error

