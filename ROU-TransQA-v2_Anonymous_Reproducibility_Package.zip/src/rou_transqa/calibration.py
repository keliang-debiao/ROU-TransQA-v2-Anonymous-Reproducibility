from __future__ import annotations

import math

import numpy as np
from scipy.optimize import minimize_scalar


def sigmoid(values: np.ndarray) -> np.ndarray:
    values = np.asarray(values, dtype=float)
    positive = values >= 0
    output = np.empty_like(values)
    output[positive] = 1.0 / (1.0 + np.exp(-values[positive]))
    exp_values = np.exp(values[~positive])
    output[~positive] = exp_values / (1.0 + exp_values)
    return output


def binary_nll(logits: np.ndarray, labels: np.ndarray, temperature: float = 1.0) -> float:
    probabilities = np.clip(sigmoid(np.asarray(logits) / temperature), 1e-12, 1 - 1e-12)
    labels = np.asarray(labels, dtype=float)
    return float(-np.mean(labels * np.log(probabilities) + (1 - labels) * np.log(1 - probabilities)))


def fit_temperature(logits: np.ndarray, labels: np.ndarray) -> float:
    def objective(log_temperature: float) -> float:
        return binary_nll(logits, labels, temperature=math.exp(log_temperature))

    result = minimize_scalar(objective, bounds=(-5.0, 5.0), method="bounded")
    if not result.success:
        raise RuntimeError("Temperature optimization did not converge")
    return float(math.exp(result.x))


def brier_score(probabilities: np.ndarray, labels: np.ndarray) -> float:
    return float(np.mean((np.asarray(probabilities) - np.asarray(labels)) ** 2))


def expected_calibration_error(probabilities: np.ndarray, labels: np.ndarray, bins: int = 15) -> float:
    probabilities = np.asarray(probabilities, dtype=float)
    labels = np.asarray(labels, dtype=float)
    edges = np.linspace(0.0, 1.0, bins + 1)
    total = len(probabilities)
    value = 0.0
    for lower, upper in zip(edges[:-1], edges[1:]):
        if upper == 1.0:
            mask = (probabilities >= lower) & (probabilities <= upper)
        else:
            mask = (probabilities >= lower) & (probabilities < upper)
        if mask.any():
            confidence = float(probabilities[mask].mean())
            frequency = float(labels[mask].mean())
            value += float(mask.sum()) / total * abs(confidence - frequency)
    return value


def calibration_summary(logits: np.ndarray, labels: np.ndarray, bins: int = 15) -> dict:
    temperature = fit_temperature(logits, labels)
    raw_probability = sigmoid(logits)
    calibrated_probability = sigmoid(logits / temperature)
    return {
        "temperature": temperature,
        "before": {
            "nll": binary_nll(logits, labels),
            "brier": brier_score(raw_probability, labels),
            "ece": expected_calibration_error(raw_probability, labels, bins),
        },
        "after": {
            "nll": binary_nll(logits, labels, temperature),
            "brier": brier_score(calibrated_probability, labels),
            "ece": expected_calibration_error(calibrated_probability, labels, bins),
        },
    }

