from __future__ import annotations

from itertools import combinations

import numpy as np
import pandas as pd
from scipy.stats import chi2_contingency


def cramers_v(left: pd.Series, right: pd.Series) -> tuple[float, float, float]:
    table = pd.crosstab(left.fillna("unknown"), right.fillna("unknown"))
    chi_square, p_value, _, _ = chi2_contingency(table, correction=False)
    n_rows = int(table.to_numpy().sum())
    denominator = n_rows * min(table.shape[0] - 1, table.shape[1] - 1)
    value = float(np.sqrt(chi_square / denominator)) if denominator > 0 else 0.0
    return value, float(chi_square), float(p_value)


def association_table(frame: pd.DataFrame, columns: list[str]) -> pd.DataFrame:
    rows: list[dict] = []
    for left, right in combinations(columns, 2):
        value, chi_square, p_value = cramers_v(frame[left], frame[right])
        if value < 0.25:
            strength = "weak"
        elif value < 0.30:
            strength = "weak-to-moderate"
        else:
            strength = "moderate"
        rows.append(
            {
                "indicator_pair": f"{left}-{right}",
                "cramers_v": value,
                "chi_square": chi_square,
                "p_value": p_value,
                "strength": strength,
            }
        )
    return pd.DataFrame(rows)


def missing_value_table(frame: pd.DataFrame) -> pd.DataFrame:
    result = frame.isna().sum().sort_values(ascending=False).rename("missing_values").reset_index()
    return result.rename(columns={"index": "field"})

