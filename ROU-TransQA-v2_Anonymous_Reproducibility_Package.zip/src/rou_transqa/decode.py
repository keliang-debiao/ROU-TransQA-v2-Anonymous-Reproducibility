from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

import numpy as np


@dataclass(frozen=True)
class DecodedSpan:
    text: str
    score: float
    start_token: int
    end_token: int
    start_char: int
    end_char: int


def joint_constrained_span(
    start_logits: Sequence[float],
    end_logits: Sequence[float],
    offsets: Sequence[Sequence[int]],
    sequence_ids: Sequence[int | None],
    context: str,
    max_answer_length: int,
) -> DecodedSpan:
    start_array = np.asarray(start_logits, dtype=float)
    end_array = np.asarray(end_logits, dtype=float)
    best: DecodedSpan | None = None
    context_tokens = [index for index, sid in enumerate(sequence_ids) if sid == 1]
    for start_token in context_tokens:
        upper = min(start_token + max_answer_length, len(offsets))
        for end_token in range(start_token, upper):
            if sequence_ids[end_token] != 1:
                break
            start_char = int(offsets[start_token][0])
            end_char = int(offsets[end_token][1])
            if end_char <= start_char:
                continue
            score = float(start_array[start_token] + end_array[end_token])
            span = DecodedSpan(
                text=context[start_char:end_char],
                score=score,
                start_token=start_token,
                end_token=end_token,
                start_char=start_char,
                end_char=end_char,
            )
            if best is None or span.score > best.score:
                best = span
    if best is None:
        return DecodedSpan("", float("-inf"), 0, 0, 0, 0)
    return best


def aggregate_windows(window_rows: list[dict], threshold: float) -> dict:
    if not window_rows:
        raise ValueError("window_rows cannot be empty")
    answerability_probability = max(float(row["answerability_probability"]) for row in window_rows)
    if answerability_probability < threshold:
        best = max(window_rows, key=lambda row: float(row.get("span_score", float("-inf"))))
        return {
            "qa_id": best["qa_id"],
            "prediction": "",
            "candidate_prediction": str(best.get("span_text", "")),
            "answerability_probability": answerability_probability,
            "span_score": None,
        }
    best = max(window_rows, key=lambda row: float(row.get("span_score", float("-inf"))))
    return {
        "qa_id": best["qa_id"],
        "prediction": str(best.get("span_text", "")),
        "candidate_prediction": str(best.get("span_text", "")),
        "answerability_probability": answerability_probability,
        "span_score": float(best.get("span_score", float("-inf"))),
    }
