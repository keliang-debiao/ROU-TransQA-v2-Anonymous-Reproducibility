from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass
class ROUTransQAOutput:
    loss: Any
    span_loss: Any
    answerability_loss: Any
    start_logits: Any
    end_logits: Any
    answerability_logits: Any


def build_model_class():
    try:
        import torch
        import torch.nn as nn
        import torch.nn.functional as functional
        from transformers import AutoModel
    except ImportError as error:
        raise RuntimeError("Install the training dependencies before constructing the model") from error

    class ROUTransQA(nn.Module):
        def __init__(
            self,
            encoder_name: str,
            answerability_loss_weight: float = 0.1,
            dropout: float = 0.1,
            use_answerability_head: bool = True,
            conditional_span_masking: bool = True,
            dynamic_penalty_weight: float = 0.0,
        ):
            super().__init__()
            self.encoder_name = encoder_name
            self.encoder = AutoModel.from_pretrained(encoder_name)
            hidden_size = int(self.encoder.config.hidden_size)
            self.dropout = nn.Dropout(dropout)
            self.qa_outputs = nn.Linear(hidden_size, 2)
            self.answerability = nn.Linear(hidden_size, 1)
            self.answerability_loss_weight = float(answerability_loss_weight)
            self.use_answerability_head = bool(use_answerability_head)
            self.conditional_span_masking = bool(conditional_span_masking)
            self.dynamic_penalty_weight = float(dynamic_penalty_weight)

        def forward(
            self,
            input_ids,
            attention_mask,
            start_positions=None,
            end_positions=None,
            answerability_labels=None,
        ):
            encoded = self.encoder(input_ids=input_ids, attention_mask=attention_mask)
            hidden = self.dropout(encoded.last_hidden_state)
            span_logits = self.qa_outputs(hidden)
            start_logits, end_logits = span_logits.unbind(dim=-1)
            if self.use_answerability_head:
                answerability_logits = self.answerability(hidden[:, 0]).squeeze(-1)
            else:
                best_start = start_logits[:, 1:].amax(dim=1)
                best_end = end_logits[:, 1:].amax(dim=1)
                answerability_logits = best_start + best_end - start_logits[:, 0] - end_logits[:, 0]

            total_loss = None
            span_loss = start_logits.sum() * 0.0
            answerability_loss = answerability_logits.sum() * 0.0
            if answerability_labels is not None and self.use_answerability_head:
                answerability_loss = functional.binary_cross_entropy_with_logits(
                    answerability_logits, answerability_labels.float()
                )
            if start_positions is not None and end_positions is not None:
                if self.conditional_span_masking and answerability_labels is not None:
                    mask = answerability_labels.bool()
                else:
                    mask = torch.ones_like(start_positions, dtype=torch.bool)
                if mask.any():
                    start_loss = functional.cross_entropy(start_logits[mask], start_positions[mask])
                    end_loss = functional.cross_entropy(end_logits[mask], end_positions[mask])
                    span_loss = 0.5 * (start_loss + end_loss)
                total_loss = span_loss + self.answerability_loss_weight * answerability_loss
                if self.dynamic_penalty_weight > 0 and answerability_labels is not None:
                    absent = ~answerability_labels.bool()
                    if absent.any():
                        penalty = functional.softplus(answerability_logits[absent]).mean()
                        total_loss = total_loss + self.dynamic_penalty_weight * penalty

            return ROUTransQAOutput(
                loss=total_loss,
                span_loss=span_loss,
                answerability_loss=answerability_loss,
                start_logits=start_logits,
                end_logits=end_logits,
                answerability_logits=answerability_logits,
            )

        def save_pretrained(self, output_dir: str) -> None:
            import json
            from pathlib import Path

            output = Path(output_dir)
            output.mkdir(parents=True, exist_ok=True)
            self.encoder.config.save_pretrained(output)
            torch.save(self.state_dict(), output / "rou_transqa_v2.pt")
            with (output / "rou_transqa_v2.json").open("w", encoding="utf-8") as handle:
                json.dump(
                    {
                        "encoder_name": self.encoder_name,
                        "answerability_loss_weight": self.answerability_loss_weight,
                        "use_answerability_head": self.use_answerability_head,
                        "conditional_span_masking": self.conditional_span_masking,
                        "dynamic_penalty_weight": self.dynamic_penalty_weight,
                    },
                    handle,
                    indent=2,
                    sort_keys=True,
                )
                handle.write("\n")

        @classmethod
        def from_pretrained(cls, output_dir: str, answerability_loss_weight: float = 0.1):
            import json
            from pathlib import Path

            with (Path(output_dir) / "rou_transqa_v2.json").open("r", encoding="utf-8") as handle:
                metadata = json.load(handle)
            model = cls(
                metadata["encoder_name"],
                answerability_loss_weight,
                use_answerability_head=metadata.get("use_answerability_head", True),
                conditional_span_masking=metadata.get("conditional_span_masking", True),
                dynamic_penalty_weight=metadata.get("dynamic_penalty_weight", 0.0),
            )
            model.load_state_dict(torch.load(Path(output_dir) / "rou_transqa_v2.pt", map_location="cpu"))
            return model

    return ROUTransQA
