from __future__ import annotations

import random
from collections import defaultdict
from dataclasses import asdict, dataclass
from typing import Any, Iterable


@dataclass(frozen=True)
class QARecord:
    qa_id: str
    contract_id: str
    question: str
    context: str
    answers: tuple[str, ...]
    answer_starts: tuple[int, ...]

    @property
    def answerable(self) -> bool:
        return bool(self.answers and self.answers[0] != "")


def _answers_from_row(row: dict[str, Any]) -> tuple[tuple[str, ...], tuple[int, ...]]:
    answers = row.get("answers") or {}
    if isinstance(answers, dict):
        texts = answers.get("text") or []
        starts = answers.get("answer_start") or []
    elif isinstance(answers, list):
        texts = [entry.get("text", "") for entry in answers]
        starts = [entry.get("answer_start", -1) for entry in answers]
    else:
        texts, starts = [], []
    clean = [(str(text), int(start)) for text, start in zip(texts, starts) if str(text)]
    if not clean:
        return (), ()
    return tuple(item[0] for item in clean), tuple(item[1] for item in clean)


def normalize_hf_rows(rows: Iterable[dict[str, Any]]) -> list[QARecord]:
    records: list[QARecord] = []
    for index, row in enumerate(rows):
        texts, starts = _answers_from_row(row)
        contract_id = str(
            row.get("title")
            or row.get("contract_id")
            or row.get("source")
            or f"contract_{index // 41:04d}"
        )
        records.append(
            QARecord(
                qa_id=str(row.get("id") or row.get("qa_id") or f"qa_{index:06d}"),
                contract_id=contract_id,
                question=str(row["question"]),
                context=str(row["context"]),
                answers=texts,
                answer_starts=starts,
            )
        )
    return records


def load_cuad(dataset_id: str, revision: str = "main", cache_dir: str | None = None) -> list[QARecord]:
    try:
        from datasets import load_dataset
    except ImportError as error:
        raise RuntimeError("Install the training dependencies before loading CUAD") from error
    dataset = load_dataset(dataset_id, revision=revision, cache_dir=cache_dir)
    rows: list[dict[str, Any]] = []
    for split in dataset:
        rows.extend(dict(item) for item in dataset[split])
    deduplicated: dict[str, dict[str, Any]] = {}
    for row in rows:
        key = str(row.get("id") or row.get("qa_id"))
        deduplicated[key] = row
    return normalize_hf_rows(deduplicated.values())


def grouped_counts(records: Iterable[QARecord]) -> dict[str, dict[str, int]]:
    counts: dict[str, dict[str, int]] = defaultdict(lambda: {"instances": 0, "answerable": 0})
    for record in records:
        counts[record.contract_id]["instances"] += 1
        counts[record.contract_id]["answerable"] += int(record.answerable)
    return dict(counts)


def contract_grouped_split(
    records: list[QARecord],
    seed: int,
    target_contracts: dict[str, int],
    target_answerable: dict[str, int] | None = None,
    refinement_steps: int = 250_000,
) -> dict[str, str]:
    """Create a deterministic contract split and refine answerable counts by pair swaps."""
    counts = grouped_counts(records)
    contract_ids = sorted(counts)
    expected_total = sum(target_contracts.values())
    if len(contract_ids) != expected_total:
        raise ValueError(f"Expected {expected_total} contracts, found {len(contract_ids)}")

    rng = random.Random(seed)
    rng.shuffle(contract_ids)
    assignment: dict[str, str] = {}
    offset = 0
    for split in ("train", "validation", "test"):
        width = target_contracts[split]
        for contract_id in contract_ids[offset : offset + width]:
            assignment[contract_id] = split
        offset += width

    if not target_answerable:
        return assignment

    by_split: dict[str, set[str]] = {name: set() for name in target_contracts}
    for contract_id, split in assignment.items():
        by_split[split].add(contract_id)

    def totals() -> dict[str, int]:
        return {
            split: sum(counts[contract_id]["answerable"] for contract_id in members)
            for split, members in by_split.items()
        }

    def objective(value: dict[str, int]) -> int:
        return sum(abs(value[name] - target_answerable[name]) for name in target_answerable)

    current = totals()
    best_score = objective(current)
    split_names = list(target_contracts)
    for _ in range(refinement_steps):
        if best_score == 0:
            break
        left, right = rng.sample(split_names, 2)
        a = rng.choice(tuple(by_split[left]))
        b = rng.choice(tuple(by_split[right]))
        proposed = dict(current)
        proposed[left] += counts[b]["answerable"] - counts[a]["answerable"]
        proposed[right] += counts[a]["answerable"] - counts[b]["answerable"]
        proposed_score = objective(proposed)
        if proposed_score <= best_score:
            by_split[left].remove(a)
            by_split[right].remove(b)
            by_split[left].add(b)
            by_split[right].add(a)
            assignment[a], assignment[b] = right, left
            current = proposed
            best_score = proposed_score

    if best_score != 0:
        raise RuntimeError(
            "Could not reach the declared answerable counts. Supply the frozen split manifest "
            f"or increase refinement_steps. Remaining absolute deviation: {best_score}"
        )
    return assignment


def split_records(records: list[QARecord], assignment: dict[str, str]) -> dict[str, list[QARecord]]:
    result: dict[str, list[QARecord]] = {"train": [], "validation": [], "test": []}
    for record in records:
        result[assignment[record.contract_id]].append(record)
    return result


def manifest_rows(records: list[QARecord], assignment: dict[str, str]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for record in sorted(records, key=lambda item: (assignment[item.contract_id], item.qa_id)):
        row = asdict(record)
        rows.append(
            {
                "qa_id": row["qa_id"],
                "contract_id": row["contract_id"],
                "split": assignment[record.contract_id],
                "answerable": int(record.answerable),
            }
        )
    return rows


def build_window_features(
    records: list[QARecord],
    tokenizer: Any,
    max_length: int,
    stride: int,
) -> list[dict[str, Any]]:
    features: list[dict[str, Any]] = []
    for record in records:
        encoded = tokenizer(
            record.question,
            record.context,
            truncation="only_second",
            max_length=max_length,
            stride=stride,
            return_overflowing_tokens=True,
            return_offsets_mapping=True,
            padding=False,
        )
        for window_index in range(len(encoded["input_ids"])):
            sequence_ids = encoded.sequence_ids(window_index)
            offsets = encoded["offset_mapping"][window_index]
            context_positions = [index for index, sid in enumerate(sequence_ids) if sid == 1]
            start_position = 0
            end_position = 0
            window_answerable = 0
            if record.answerable and context_positions:
                context_start = context_positions[0]
                context_end = context_positions[-1]
                for answer_text, answer_start in zip(record.answers, record.answer_starts):
                    answer_end = answer_start + len(answer_text)
                    if offsets[context_start][0] <= answer_start and offsets[context_end][1] >= answer_end:
                        token_start = context_start
                        while token_start <= context_end and offsets[token_start][0] <= answer_start:
                            token_start += 1
                        token_end = context_end
                        while token_end >= context_start and offsets[token_end][1] >= answer_end:
                            token_end -= 1
                        start_position = token_start - 1
                        end_position = token_end + 1
                        window_answerable = 1
                        break
            features.append(
                {
                    "qa_id": record.qa_id,
                    "contract_id": record.contract_id,
                    "question": record.question,
                    "context": record.context,
                    "gold_answers": list(record.answers),
                    "input_ids": encoded["input_ids"][window_index],
                    "attention_mask": encoded["attention_mask"][window_index],
                    "offset_mapping": offsets,
                    "sequence_ids": sequence_ids,
                    "start_positions": start_position,
                    "end_positions": end_position,
                    "answerability_labels": window_answerable,
                }
            )
    return features

