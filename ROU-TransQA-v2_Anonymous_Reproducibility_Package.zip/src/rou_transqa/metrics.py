from __future__ import annotations

import re
import string
from collections import Counter
from typing import Iterable

import numpy as np


def normalize_answer(text: str) -> str:
    def remove_articles(value: str) -> str:
        return re.sub(r"\b(a|an|the)\b", " ", value)

    def remove_punctuation(value: str) -> str:
        return "".join(character for character in value if character not in set(string.punctuation))

    return " ".join(remove_articles(remove_punctuation(text.lower())).split())


def exact_match(prediction: str, gold: str) -> float:
    return float(normalize_answer(prediction) == normalize_answer(gold))


def token_f1(prediction: str, gold: str) -> float:
    prediction_tokens = normalize_answer(prediction).split()
    gold_tokens = normalize_answer(gold).split()
    if not prediction_tokens or not gold_tokens:
        return float(prediction_tokens == gold_tokens)
    overlap = Counter(prediction_tokens) & Counter(gold_tokens)
    common = sum(overlap.values())
    if common == 0:
        return 0.0
    precision = common / len(prediction_tokens)
    recall = common / len(gold_tokens)
    return 2.0 * precision * recall / (precision + recall)


def best_gold_score(prediction: str, gold_answers: Iterable[str], scorer) -> float:
    gold_list = list(gold_answers)
    if not gold_list:
        gold_list = [""]
    return max(scorer(prediction, gold) for gold in gold_list)


def qa_metrics(rows: list[dict]) -> dict[str, float | int]:
    if not rows:
        raise ValueError("At least one prediction row is required")
    em_values: list[float] = []
    f1_values: list[float] = []
    has_f1: list[float] = []
    no_f1: list[float] = []
    for row in rows:
        prediction = str(row.get("prediction", ""))
        gold_answers = row.get("gold_answers") or [""]
        answerable = any(normalize_answer(str(value)) for value in gold_answers)
        em = best_gold_score(prediction, gold_answers, exact_match)
        f1 = best_gold_score(prediction, gold_answers, token_f1)
        em_values.append(em)
        f1_values.append(f1)
        (has_f1 if answerable else no_f1).append(f1)
    has_value = float(np.mean(has_f1)) if has_f1 else float("nan")
    no_value = float(np.mean(no_f1)) if no_f1 else float("nan")
    return {
        "count": len(rows),
        "answerable_count": len(has_f1),
        "unanswerable_count": len(no_f1),
        "em": 100.0 * float(np.mean(em_values)),
        "overall_f1": 100.0 * float(np.mean(f1_values)),
        "has_answer_f1": 100.0 * has_value,
        "no_answer_f1": 100.0 * no_value,
        "macro_qa_f1": 50.0 * (has_value + no_value),
    }


def answerability_metrics(rows: list[dict], threshold: float) -> dict[str, float | int]:
    true_values: list[int] = []
    predicted_values: list[int] = []
    probabilities: list[float] = []
    for row in rows:
        gold_answers = row.get("gold_answers") or [""]
        true_values.append(int(any(normalize_answer(str(value)) for value in gold_answers)))
        probability = float(row["answerability_probability"])
        probabilities.append(probability)
        predicted_values.append(int(probability >= threshold))
    y_true = np.asarray(true_values, dtype=int)
    y_pred = np.asarray(predicted_values, dtype=int)
    tp = int(((y_true == 1) & (y_pred == 1)).sum())
    tn = int(((y_true == 0) & (y_pred == 0)).sum())
    fp = int(((y_true == 0) & (y_pred == 1)).sum())
    fn = int(((y_true == 1) & (y_pred == 0)).sum())
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    specificity = tn / (tn + fp) if tn + fp else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    accuracy = (tp + tn) / len(y_true)
    result: dict[str, float | int] = {
        "count": len(y_true),
        "tp": tp,
        "tn": tn,
        "fp": fp,
        "fn": fn,
        "accuracy": 100.0 * accuracy,
        "precision": 100.0 * precision,
        "recall": 100.0 * recall,
        "specificity": 100.0 * specificity,
        "f1": 100.0 * f1,
    }
    if len(set(true_values)) == 2:
        from sklearn.metrics import average_precision_score, roc_auc_score

        result["auroc"] = float(roc_auc_score(y_true, probabilities))
        result["auprc"] = float(average_precision_score(y_true, probabilities))
    return result


def indicator_macro_f1(rows: list[dict], labels: tuple[str, ...] = ("yes", "no", "unknown")) -> dict:
    from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score

    indicators = [f"D{index}" for index in range(1, 7)]
    per_indicator: dict[str, dict[str, float]] = {}
    all_true: list[str] = []
    all_predicted: list[str] = []
    for indicator in indicators:
        true_values = [str(row[f"gold_{indicator}"]).lower() for row in rows]
        predicted_values = [str(row[f"predicted_{indicator}"]).lower() for row in rows]
        all_true.extend(true_values)
        all_predicted.extend(predicted_values)
        per_indicator[indicator] = {
            "accuracy": float(accuracy_score(true_values, predicted_values)),
            "precision_macro": float(
                precision_score(true_values, predicted_values, labels=list(labels), average="macro", zero_division=0)
            ),
            "recall_macro": float(
                recall_score(true_values, predicted_values, labels=list(labels), average="macro", zero_division=0)
            ),
            "f1_macro": float(
                f1_score(true_values, predicted_values, labels=list(labels), average="macro", zero_division=0)
            ),
        }
    return {
        "overall_accuracy": float(accuracy_score(all_true, all_predicted)),
        "overall_macro_f1": float(
            f1_score(all_true, all_predicted, labels=list(labels), average="macro", zero_division=0)
        ),
        "per_indicator": per_indicator,
    }

