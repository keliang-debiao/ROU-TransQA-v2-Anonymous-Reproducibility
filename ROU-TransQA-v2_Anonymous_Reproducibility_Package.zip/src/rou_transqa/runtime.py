from __future__ import annotations

import math
from collections import defaultdict
from pathlib import Path
from typing import Any

from .decode import aggregate_windows, joint_constrained_span
from .io import write_json, write_jsonl
from .metrics import qa_metrics


def _torch():
    try:
        import torch

        return torch
    except ImportError as error:
        raise RuntimeError("Install the training dependencies before running this command") from error


def feature_batches(features: list[dict[str, Any]], batch_size: int, shuffle: bool, seed: int):
    import random

    indices = list(range(len(features)))
    if shuffle:
        random.Random(seed).shuffle(indices)
    for offset in range(0, len(indices), batch_size):
        yield [features[index] for index in indices[offset : offset + batch_size]]


def tensor_batch(rows: list[dict[str, Any]], tokenizer: Any, device: Any, include_labels: bool) -> dict:
    torch = _torch()
    encoded = tokenizer.pad(
        [{"input_ids": row["input_ids"], "attention_mask": row["attention_mask"]} for row in rows],
        padding=True,
        return_tensors="pt",
    )
    batch = {key: value.to(device) for key, value in encoded.items()}
    if include_labels:
        for key in ("start_positions", "end_positions", "answerability_labels"):
            batch[key] = torch.tensor([row[key] for row in rows], dtype=torch.long, device=device)
    return batch


def run_inference(
    model: Any,
    tokenizer: Any,
    features: list[dict[str, Any]],
    batch_size: int,
    threshold: float,
    max_answer_length: int,
    device: Any,
) -> tuple[list[dict], dict]:
    torch = _torch()
    model.eval()
    per_question: dict[str, list[dict]] = defaultdict(list)
    gold: dict[str, list[str]] = {}
    with torch.no_grad():
        for rows in feature_batches(features, batch_size, shuffle=False, seed=0):
            batch = tensor_batch(rows, tokenizer, device, include_labels=False)
            output = model(input_ids=batch["input_ids"], attention_mask=batch["attention_mask"])
            probabilities = torch.sigmoid(output.answerability_logits).detach().cpu().numpy()
            start_logits = output.start_logits.detach().cpu().numpy()
            end_logits = output.end_logits.detach().cpu().numpy()
            for index, row in enumerate(rows):
                width = len(row["offset_mapping"])
                span = joint_constrained_span(
                    start_logits[index][:width],
                    end_logits[index][:width],
                    row["offset_mapping"],
                    row["sequence_ids"],
                    row["context"],
                    max_answer_length,
                )
                per_question[row["qa_id"]].append(
                    {
                        "qa_id": row["qa_id"],
                        "answerability_probability": float(probabilities[index]),
                        "answerability_logit": float(output.answerability_logits[index].detach().cpu()),
                        "span_text": span.text,
                        "span_score": span.score,
                    }
                )
                gold[row["qa_id"]] = list(row["gold_answers"])
    predictions: list[dict] = []
    for qa_id in sorted(per_question):
        result = aggregate_windows(per_question[qa_id], threshold)
        result["gold_answers"] = gold[qa_id]
        result["answerability_logit"] = max(
            float(row["answerability_logit"]) for row in per_question[qa_id]
        )
        predictions.append(result)
    return predictions, qa_metrics(predictions)


def train_model(
    model: Any,
    tokenizer: Any,
    train_features: list[dict[str, Any]],
    validation_features: list[dict[str, Any]],
    config: dict,
    seed: int,
    output_dir: str | Path,
) -> dict:
    torch = _torch()
    from transformers import get_linear_schedule_with_warmup

    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    settings = config["training"]
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=float(settings["learning_rate"]),
        weight_decay=float(settings["weight_decay"]),
    )
    batches_per_epoch = math.ceil(len(train_features) / int(settings["batch_size"]))
    total_steps = int(settings["epochs"]) * batches_per_epoch
    warmup_steps = int(total_steps * float(settings["warmup_ratio"]))
    scheduler = get_linear_schedule_with_warmup(optimizer, warmup_steps, total_steps)
    use_amp = device.type == "cuda" and settings.get("mixed_precision") == "fp16"
    scaler = torch.cuda.amp.GradScaler(enabled=use_amp)
    history: list[dict] = []
    best_metric = float("-inf")
    best_epoch = 0
    for epoch in range(1, int(settings["epochs"]) + 1):
        model.train()
        losses: list[float] = []
        for rows in feature_batches(train_features, int(settings["batch_size"]), True, seed + epoch):
            batch = tensor_batch(rows, tokenizer, device, include_labels=True)
            optimizer.zero_grad(set_to_none=True)
            with torch.cuda.amp.autocast(enabled=use_amp):
                result = model(**batch)
                loss = result.loss
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), float(settings["max_grad_norm"]))
            scaler.step(optimizer)
            scaler.update()
            scheduler.step()
            losses.append(float(loss.detach().cpu()))
        predictions, metrics = run_inference(
            model,
            tokenizer,
            validation_features,
            int(settings["batch_size"]),
            float(config["inference"]["threshold"]),
            int(config["model"]["max_answer_length"]),
            device,
        )
        epoch_row = {"epoch": epoch, "training_loss": sum(losses) / len(losses), **metrics}
        history.append(epoch_row)
        write_jsonl(output / "training_history.jsonl", history)
        write_jsonl(output / "validation_predictions.jsonl", predictions)
        if float(metrics["macro_qa_f1"]) > best_metric:
            best_metric = float(metrics["macro_qa_f1"])
            best_epoch = epoch
            model.save_pretrained(output / "best")
            tokenizer.save_pretrained(output / "best")
            write_json(output / "best" / "validation_metrics.json", metrics)
    summary = {
        "seed": seed,
        "device": str(device),
        "best_epoch": best_epoch,
        "best_macro_qa_f1": best_metric,
        "epochs": history,
    }
    write_json(output / "training_summary.json", summary)
    return summary

