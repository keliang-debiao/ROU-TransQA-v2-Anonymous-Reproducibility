#!/usr/bin/env bash
set -euo pipefail

for seed in 13 21 42 2024 2025; do
  python scripts/train.py --config configs/main.yaml --seed "${seed}"
  python scripts/evaluate.py \
    --config configs/main.yaml \
    --checkpoint "outputs/seed_${seed}/best" \
    --split test
done

