#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
from pathlib import Path

from _path import add_src

ROOT = add_src()

from rou_transqa.data import build_window_features, load_cuad, split_records
from rou_transqa.io import read_yaml
from rou_transqa.model import build_model_class
from rou_transqa.runtime import train_model
from rou_transqa.utils import set_global_seed


def read_assignment(path: Path) -> dict[str, str]:
    with path.open("r", encoding="utf-8") as handle:
        return {row["contract_id"]: row["split"] for row in csv.DictReader(handle)}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--seed", type=int, required=True)
    args = parser.parse_args()
    config = read_yaml(args.config)
    set_global_seed(args.seed)
    try:
        from transformers import AutoTokenizer
    except ImportError as error:
        raise RuntimeError("Install the training dependencies before training") from error

    data = config["data"]
    model_config = config["model"]
    assignment_path = ROOT / data["manifest_dir"] / "contract_manifest.csv"
    if not assignment_path.exists():
        raise FileNotFoundError("Run scripts/prepare_cuad.py before training")
    assignment = read_assignment(assignment_path)
    records = load_cuad(data["dataset_id"], data["dataset_revision"], data["cache_dir"])
    split = split_records(records, assignment)
    tokenizer = AutoTokenizer.from_pretrained(model_config["encoder"], use_fast=True)
    train_features = build_window_features(
        split["train"], tokenizer, int(model_config["max_length"]), int(model_config["stride"])
    )
    validation_features = build_window_features(
        split["validation"], tokenizer, int(model_config["max_length"]), int(model_config["stride"])
    )
    model_class = build_model_class()
    model = model_class(
        model_config["encoder"],
        float(model_config["answerability_loss_weight"]),
        float(model_config["dropout"]),
        bool(model_config.get("use_answerability_head", True)),
        bool(model_config.get("conditional_span_masking", True)),
        float(model_config.get("dynamic_penalty_weight", 0.0)),
    )
    output = ROOT / config["project"]["output_root"] / f"seed_{args.seed}"
    train_model(model, tokenizer, train_features, validation_features, config, args.seed, output)


if __name__ == "__main__":
    main()
