#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
from pathlib import Path

from _path import add_src

ROOT = add_src()

from rou_transqa.data import build_window_features, load_cuad, split_records
from rou_transqa.io import read_yaml, write_json, write_jsonl
from rou_transqa.model import build_model_class
from rou_transqa.runtime import run_inference


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--split", choices=["validation", "test"], default="test")
    args = parser.parse_args()
    config = read_yaml(args.config)
    try:
        import torch
        from transformers import AutoTokenizer
    except ImportError as error:
        raise RuntimeError("Install the training dependencies before evaluation") from error

    manifest = ROOT / config["data"]["manifest_dir"] / "contract_manifest.csv"
    with manifest.open("r", encoding="utf-8") as handle:
        assignment = {row["contract_id"]: row["split"] for row in csv.DictReader(handle)}
    data = config["data"]
    records = load_cuad(data["dataset_id"], data["dataset_revision"], data["cache_dir"])
    split = split_records(records, assignment)
    checkpoint = Path(args.checkpoint)
    tokenizer = AutoTokenizer.from_pretrained(checkpoint, use_fast=True)
    model_class = build_model_class()
    model = model_class.from_pretrained(
        str(checkpoint), float(config["model"]["answerability_loss_weight"])
    )
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    features = build_window_features(
        split[args.split],
        tokenizer,
        int(config["model"]["max_length"]),
        int(config["model"]["stride"]),
    )
    predictions, metrics = run_inference(
        model,
        tokenizer,
        features,
        int(config["training"]["batch_size"]),
        float(config["inference"]["threshold"]),
        int(config["model"]["max_answer_length"]),
        device,
    )
    output_dir = checkpoint.parent
    write_jsonl(output_dir / f"{args.split}_predictions.jsonl", predictions)
    write_json(output_dir / f"{args.split}_metrics.json", metrics)
    print(metrics)


if __name__ == "__main__":
    main()

