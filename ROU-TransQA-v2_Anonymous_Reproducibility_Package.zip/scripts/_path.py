from pathlib import Path
import sys


def add_src() -> Path:
    root = Path(__file__).resolve().parents[1]
    source = root / "src"
    if str(source) not in sys.path:
        sys.path.insert(0, str(source))
    return root

