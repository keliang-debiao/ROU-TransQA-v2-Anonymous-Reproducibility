#!/usr/bin/env python3
from __future__ import annotations

import json

import numpy as np

from _path import add_src

add_src()

from rou_transqa.calibration import calibration_summary
from rou_transqa.mapping import map_d1_d6
from rou_transqa.metrics import answerability_metrics, qa_metrics


def main() -> None:
    rows = [
        {"qa_id": "q1", "prediction": "New York", "gold_answers": ["New York"], "answerability_probability": 0.94},
        {"qa_id": "q2", "prediction": "", "gold_answers": [""], "answerability_probability": 0.02},
        {"qa_id": "q3", "prediction": "variable rent", "gold_answers": ["variable rent"], "answerability_probability": 0.83},
        {"qa_id": "q4", "prediction": "", "gold_answers": [""], "answerability_probability": 0.08},
        {"qa_id": "q5", "prediction": "", "gold_answers": ["renewal option"], "answerability_probability": 0.07},
        {"qa_id": "q6", "prediction": "", "gold_answers": [""], "answerability_probability": 0.04},
    ]
    mapping = map_d1_d6(
        {
            "lease_identification": "The agreement contains an identified asset and a lease.",
            "lease_term": "The lease term is 36 months.",
            "low_value": "The asset value is material.",
            "renewal": "The lessee may renew the lease for two years.",
            "variable_payment": "Variable rent is linked to annual sales.",
            "discount_rate": "The incremental borrowing rate is disclosed.",
        }
    )
    logits = np.asarray([2.8, -3.2, 1.9, -2.4, -1.8, -2.9])
    labels = np.asarray([1, 0, 1, 0, 1, 0])
    output = {
        "qa_metrics": qa_metrics(rows),
        "answerability_metrics": answerability_metrics(rows, 0.10),
        "calibration": calibration_summary(logits, labels, bins=3),
        "mapping": {f"D{index}": getattr(mapping, f"D{index}") for index in range(1, 7)},
        "status": "passed",
    }
    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()

