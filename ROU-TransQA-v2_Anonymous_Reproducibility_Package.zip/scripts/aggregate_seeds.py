#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np

from _path import add_src

add_src()

from rou_transqa.io import read_json, write_json
from rou_transqa.statistics import t_confidence_interval


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-dir", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    root = Path(args.input_dir)
    rows = []
    for path in sorted(root.glob("seed_*/test_metrics.json")):
        row = read_json(path)
        row["seed"] = int(path.parent.name.split("_")[-1])
        rows.append(row)
    if len(rows) != 5:
        raise RuntimeError(f"Expected five seed results, found {len(rows)}")
    summary = {"seeds": [row["seed"] for row in rows], "metrics": {}}
    for metric in ("em", "overall_f1", "has_answer_f1", "no_answer_f1", "macro_qa_f1"):
        values = [float(row[metric]) for row in rows]
        lower, upper = t_confidence_interval(values)
        summary["metrics"][metric] = {
            "mean": float(np.mean(values)),
            "sd": float(np.std(values, ddof=1)),
            "ci95": [lower, upper],
            "values": values,
        }
    write_json(args.output, summary)
    print(summary)


if __name__ == "__main__":
    main()

