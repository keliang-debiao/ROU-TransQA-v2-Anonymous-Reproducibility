#!/usr/bin/env python3
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

import yaml

from _path import add_src

ROOT = add_src()

from rou_transqa.io import read_yaml


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    baseline_config = read_yaml(args.config)
    if args.model not in baseline_config["encoder_models"]:
        raise KeyError(f"Unknown encoder baseline: {args.model}")
    config = read_yaml(ROOT / baseline_config["base_config"])
    selected = baseline_config["encoder_models"][args.model]
    protocol = baseline_config["encoder_protocol"]
    config["project"]["output_root"] = f"outputs/baselines/{args.model}"
    config["model"].update(
        {
            "encoder": selected["identifier"],
            "max_length": selected["max_length"],
            "stride": selected["stride"],
            "use_answerability_head": protocol["use_answerability_head"],
            "conditional_span_masking": protocol["conditional_span_masking"],
            "answerability_loss_weight": protocol["answerability_loss_weight"],
        }
    )
    config["training"]["learning_rate"] = selected["learning_rate"]
    generated = ROOT / "outputs" / "baselines" / args.model / "frozen_config.yaml"
    generated.parent.mkdir(parents=True, exist_ok=True)
    with generated.open("w", encoding="utf-8") as handle:
        yaml.safe_dump(config, handle, sort_keys=False)
    subprocess.run(
        [sys.executable, str(ROOT / "scripts" / "train.py"), "--config", str(generated), "--seed", str(args.seed)],
        check=True,
        cwd=ROOT,
    )
    checkpoint = ROOT / config["project"]["output_root"] / f"seed_{args.seed}" / "best"
    subprocess.run(
        [
            sys.executable,
            str(ROOT / "scripts" / "evaluate.py"),
            "--config",
            str(generated),
            "--checkpoint",
            str(checkpoint),
            "--split",
            "test",
        ],
        check=True,
        cwd=ROOT,
    )


if __name__ == "__main__":
    main()

