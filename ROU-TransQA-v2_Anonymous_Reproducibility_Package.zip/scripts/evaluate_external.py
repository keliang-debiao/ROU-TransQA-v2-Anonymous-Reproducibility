#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
from collections import defaultdict
from pathlib import Path

from _path import add_src

ROOT = add_src()

from rou_transqa.data import QARecord, build_window_features
from rou_transqa.io import read_yaml, write_json, write_jsonl
from rou_transqa.mapping import map_d1_d6
from rou_transqa.metrics import indicator_macro_f1, qa_metrics
from rou_transqa.model import build_model_class
from rou_transqa.runtime import run_inference


def load_rows(path: Path, identity_fields: list[str]) -> list[dict]:
    with path.open("r", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    if not rows:
        raise ValueError("The external validation file is empty")
    prohibited = sorted(set(rows[0]).intersection(identity_fields))
    if prohibited:
        raise ValueError(f"Identity fields must be removed before evaluation: {prohibited}")
    return rows


def qa_records(rows: list[dict]) -> list[QARecord]:
    output = []
    for row in rows:
        answer = row.get("gold_answer", "")
        start = int(row.get("answer_start", -1))
        output.append(
            QARecord(
                qa_id=row["question_id"],
                contract_id=row["contract_id"],
                question=row["question"],
                context=row["context"],
                answers=(answer,) if answer else (),
                answer_starts=(start,) if answer else (),
            )
        )
    return output


def mapping_rows(source_rows: list[dict], predictions: list[dict]) -> list[dict]:
    prediction_index = {row["qa_id"]: row for row in predictions}
    evidence: dict[str, dict[str, list[str]]] = defaultdict(lambda: defaultdict(list))
    contract_gold: dict[str, dict[str, str]] = {}
    for row in source_rows:
        prediction = prediction_index[row["question_id"]]["prediction"]
        if prediction:
            evidence[row["contract_id"]][row["mapping_field"]].append(prediction)
        contract_gold.setdefault(
            row["contract_id"], {f"D{index}": row[f"D{index}"].lower() for index in range(1, 7)}
        )
    output = []
    for contract_id in sorted(contract_gold):
        collapsed = {key: " ".join(values) for key, values in evidence[contract_id].items()}
        mapped = map_d1_d6(collapsed)
        output.append(
            {
                "contract_id": contract_id,
                **{f"gold_D{index}": contract_gold[contract_id][f"D{index}"] for index in range(1, 7)},
                **{f"predicted_D{index}": getattr(mapped, f"D{index}") for index in range(1, 7)},
            }
        )
    return output


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    external_config = read_yaml(args.config)
    base_config = read_yaml(ROOT / external_config["base_config"])
    settings = external_config["external"]
    rows = load_rows(ROOT / settings["input_csv"], list(settings["identity_fields"]))
    if len(rows) != int(settings["expected_total_qa"]):
        raise ValueError(f"Expected {settings['expected_total_qa']} QA rows, found {len(rows)}")

    try:
        import torch
        from transformers import AutoTokenizer
    except ImportError as error:
        raise RuntimeError("Install the training dependencies before external evaluation") from error
    checkpoint = ROOT / settings["checkpoint"]
    tokenizer = AutoTokenizer.from_pretrained(checkpoint, use_fast=True)
    model_class = build_model_class()
    model = model_class.from_pretrained(
        str(checkpoint), float(base_config["model"]["answerability_loss_weight"])
    )
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    features = build_window_features(
        qa_records(rows),
        tokenizer,
        int(base_config["model"]["max_length"]),
        int(base_config["model"]["stride"]),
    )
    predictions, overall_qa = run_inference(
        model,
        tokenizer,
        features,
        int(base_config["training"]["batch_size"]),
        float(base_config["inference"]["threshold"]),
        int(base_config["model"]["max_answer_length"]),
        device,
    )
    mapped = mapping_rows(rows, predictions)
    qa_to_subset = {row["question_id"]: row["subset"] for row in rows}
    contract_to_subset = {row["contract_id"]: row["subset"] for row in rows}
    subset_results = {}
    for subset in settings["subsets"]:
        subset_predictions = [row for row in predictions if qa_to_subset[row["qa_id"]] == subset]
        subset_mapping = [row for row in mapped if contract_to_subset[row["contract_id"]] == subset]
        subset_results[subset] = {
            "qa": qa_metrics(subset_predictions),
            "mapping": indicator_macro_f1(subset_mapping),
        }
    result = {
        "threshold_source": settings["threshold_source"],
        "threshold_refit": bool(settings["allow_threshold_refit"]),
        "overall": {"qa": overall_qa, "mapping": indicator_macro_f1(mapped)},
        "subsets": subset_results,
    }
    output_dir = ROOT / "outputs" / "external"
    write_jsonl(output_dir / "qa_predictions.jsonl", predictions)
    write_jsonl(output_dir / "indicator_predictions.jsonl", mapped)
    write_json(output_dir / "metrics.json", result)
    print(result)


if __name__ == "__main__":
    main()

