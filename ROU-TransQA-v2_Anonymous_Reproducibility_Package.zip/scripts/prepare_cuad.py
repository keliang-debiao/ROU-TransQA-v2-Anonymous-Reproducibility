#!/usr/bin/env python3
from __future__ import annotations

import argparse

from _path import add_src

ROOT = add_src()

from rou_transqa.data import contract_grouped_split, load_cuad, manifest_rows, split_records
from rou_transqa.io import read_yaml, write_csv, write_json


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    config = read_yaml(args.config)
    data = config["data"]
    records = load_cuad(data["dataset_id"], data["dataset_revision"], data["cache_dir"])
    assignment = contract_grouped_split(
        records,
        int(data["split_seed"]),
        {key: int(value) for key, value in data["expected_contracts"].items()},
        {key: int(value) for key, value in data["expected_answerable"].items()},
    )
    split = split_records(records, assignment)
    output_dir = ROOT / data["manifest_dir"]
    write_csv(output_dir / "qa_manifest.csv", manifest_rows(records, assignment))
    contract_rows = [
        {"contract_id": contract_id, "split": split_name}
        for contract_id, split_name in sorted(assignment.items())
    ]
    write_csv(output_dir / "contract_manifest.csv", contract_rows)
    summary = {}
    for split_name, rows in split.items():
        summary[split_name] = {
            "contracts": len({row.contract_id for row in rows}),
            "instances": len(rows),
            "answerable": sum(row.answerable for row in rows),
            "unanswerable": sum(not row.answerable for row in rows),
        }
    write_json(output_dir / "split_summary.json", summary)
    print(summary)


if __name__ == "__main__":
    main()

