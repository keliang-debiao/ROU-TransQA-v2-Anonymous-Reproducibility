#!/usr/bin/env python3
from __future__ import annotations

import argparse

import pandas as pd

from _path import add_src

ROOT = add_src()

from rou_transqa.analysis import association_table, missing_value_table
from rou_transqa.io import read_yaml


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--output-dir", default="outputs/disclosure")
    args = parser.parse_args()
    config = read_yaml(args.config)
    input_path = ROOT / config["data"]["ifrs16_csv"]
    frame = pd.read_csv(input_path)
    output = ROOT / args.output_dir
    output.mkdir(parents=True, exist_ok=True)
    for column in [f"D{index}" for index in range(1, 7)] + ["B2", "B3", "B4"]:
        if column in frame:
            frame[column] = frame[column].fillna("unknown").astype(str).str.lower()
    missing_value_table(frame).to_csv(output / "missing_values.csv", index=False)
    association_table(frame, [f"D{index}" for index in range(1, 7)]).to_csv(
        output / "d1_d6_associations.csv", index=False
    )
    selected = [column for column in ("B2", "B3", "B4") if column in frame]
    counts = {column: frame[column].value_counts().to_dict() for column in selected}
    pd.DataFrame(counts).fillna(0).to_csv(output / "disclosure_status_counts.csv")
    print({"rows": len(frame), "output_dir": str(output)})


if __name__ == "__main__":
    main()

