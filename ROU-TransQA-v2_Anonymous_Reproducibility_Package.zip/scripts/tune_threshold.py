#!/usr/bin/env python3
from __future__ import annotations

import argparse

from _path import add_src

add_src()

from rou_transqa.io import read_jsonl, read_yaml, write_json
from rou_transqa.metrics import qa_metrics


def apply_threshold(rows: list[dict], threshold: float) -> list[dict]:
    output = []
    for row in rows:
        updated = dict(row)
        updated["prediction"] = (
            str(row.get("candidate_prediction", row.get("prediction", "")))
            if float(row["answerability_probability"]) >= threshold
            else ""
        )
        output.append(updated)
    return output


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--predictions", required=True)
    parser.add_argument("--config", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    rows = read_jsonl(args.predictions)
    config = read_yaml(args.config)
    candidates = []
    floor = float(config["inference"]["no_answer_f1_floor"])
    for threshold in config["inference"]["threshold_grid"]:
        metrics = qa_metrics(apply_threshold(rows, float(threshold)))
        candidates.append({"threshold": float(threshold), **metrics})
    eligible = [row for row in candidates if float(row["no_answer_f1"]) >= floor]
    if not eligible:
        raise RuntimeError("No threshold satisfies the configured NoAns F1 floor")
    selected = max(eligible, key=lambda row: (float(row["has_answer_f1"]), -float(row["threshold"])))
    write_json(
        args.output,
        {
            "selection_split": "validation",
            "constraint": {"metric": "no_answer_f1", "minimum": floor},
            "objective": "maximize_has_answer_f1",
            "selected": selected,
            "candidates": candidates,
        },
    )
    print(selected)


if __name__ == "__main__":
    main()

