#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json

from _path import add_src

add_src()

from rou_transqa.io import read_jsonl, write_csv
from rou_transqa.mapping import map_d1_d6


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--low-value-threshold", type=float)
    args = parser.parse_args()
    output_rows = []
    for row in read_jsonl(args.input):
        result = map_d1_d6(row.get("evidence", {}), args.low_value_threshold)
        output_rows.append(
            {
                "contract_id": row["contract_id"],
                "D1": result.D1,
                "D2": result.D2,
                "D3": result.D3,
                "D4": result.D4,
                "D5": result.D5,
                "D6": result.D6,
                "trace_json": json.dumps(result.trace, sort_keys=True),
            }
        )
    write_csv(args.output, output_rows)
    print({"contracts": len(output_rows), "output": args.output})


if __name__ == "__main__":
    main()

