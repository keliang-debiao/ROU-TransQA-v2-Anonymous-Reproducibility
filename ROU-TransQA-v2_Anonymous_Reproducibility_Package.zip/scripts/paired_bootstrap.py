#!/usr/bin/env python3
from __future__ import annotations

import argparse

from _path import add_src

add_src()

from rou_transqa.io import read_jsonl, write_json
from rou_transqa.metrics import qa_metrics
from rou_transqa.statistics import paired_bootstrap


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--system-a", required=True)
    parser.add_argument("--system-b", required=True)
    parser.add_argument("--metric", choices=["overall_f1", "has_answer_f1", "no_answer_f1"], default="overall_f1")
    parser.add_argument("--resamples", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=2025)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    rows_a = read_jsonl(args.system_a)
    rows_b = read_jsonl(args.system_b)
    rows_a.sort(key=lambda row: row["qa_id"])
    rows_b.sort(key=lambda row: row["qa_id"])
    result = paired_bootstrap(
        rows_a,
        rows_b,
        metric=lambda rows: float(qa_metrics(rows)[args.metric]),
        resamples=args.resamples,
        seed=args.seed,
    )
    result["metric"] = args.metric
    write_json(args.output, result)
    print(result)


if __name__ == "__main__":
    main()

