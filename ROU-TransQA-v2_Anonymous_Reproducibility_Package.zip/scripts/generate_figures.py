#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns


def save_figure(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    plt.tight_layout()
    plt.savefig(path.with_suffix(".png"), dpi=300, bbox_inches="tight")
    plt.savefig(path.with_suffix(".pdf"), bbox_inches="tight")
    plt.close()


def threshold_figure(records: Path, output: Path) -> None:
    frame = pd.read_csv(records / "thresholds.csv")
    plt.figure(figsize=(7.2, 4.2))
    for column, label in (
        ("em", "EM"),
        ("overall_f1", "Overall F1"),
        ("has_answer_f1", "HasAns F1"),
        ("no_answer_f1", "NoAns F1"),
    ):
        plt.plot(frame["threshold"], frame[column], marker="o", label=label)
    plt.axvline(0.10, color="#b44b4b", linestyle="--", linewidth=1.2, label="Selected 0.10")
    plt.xlabel("Answerability threshold")
    plt.ylabel("Performance (%)")
    plt.ylim(0, 102)
    plt.legend(frameon=False, ncol=2)
    save_figure(output / "threshold_sensitivity")


def association_figure(records: Path, output: Path) -> None:
    frame = pd.read_csv(records / "associations.csv")
    labels = [f"D{index}" for index in range(1, 7)]
    matrix = pd.DataFrame(np.eye(6), index=labels, columns=labels)
    for row in frame.to_dict("records"):
        left, right = row["indicator_pair"].split("-")
        matrix.loc[left, right] = matrix.loc[right, left] = float(row["cramers_v"])
    plt.figure(figsize=(6.2, 5.2))
    sns.heatmap(matrix, annot=True, fmt=".2f", cmap="Blues", vmin=0, vmax=1, square=True)
    plt.title("Categorical association among D1-D6")
    save_figure(output / "d1_d6_cramers_v")


def disclosure_figure(records: Path, output: Path) -> None:
    frame = pd.read_csv(records / "disclosure_status.csv").set_index("field")
    frame[["yes", "no", "unknown"]].plot(
        kind="bar", stacked=True, color=["#4472C4", "#ED7D31", "#70AD47"], figsize=(7.2, 4.4)
    )
    plt.xlabel("Disclosure field")
    plt.ylabel("Number of records")
    plt.xticks(rotation=0)
    plt.legend(frameon=False, ncol=3)
    save_figure(output / "disclosure_status")


def model_figure(records: Path, output: Path) -> None:
    frame = pd.read_csv(records / "model_comparison.csv")
    selected = frame[frame["model"].isin(["LexLM-large-QA", "Saul-7B-Instruct-v1", "ROU-TransQA-v2"])]
    plot = selected.set_index("model")[["has_answer_f1", "no_answer_f1", "macro_qa_f1"]]
    plot.plot(kind="bar", figsize=(8.2, 4.6), color=["#70AD47", "#C55A11", "#5B9BD5"])
    plt.xlabel("")
    plt.ylabel("F1 (%)")
    plt.xticks(rotation=12, ha="right")
    plt.legend(["HasAns F1", "NoAns F1", "Macro-QA F1"], frameon=False)
    save_figure(output / "controlled_model_comparison")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--records", required=True)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()
    records = Path(args.records)
    output = Path(args.output_dir)
    sns.set_theme(style="whitegrid", font_scale=1.0)
    threshold_figure(records, output)
    association_figure(records, output)
    disclosure_figure(records, output)
    model_figure(records, output)
    print({"figures": 4, "output_dir": str(output)})


if __name__ == "__main__":
    main()

