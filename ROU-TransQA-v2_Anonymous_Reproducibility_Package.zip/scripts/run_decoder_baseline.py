#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
from collections import defaultdict
from pathlib import Path

from _path import add_src

ROOT = add_src()

from rou_transqa.data import QARecord, load_cuad, split_records
from rou_transqa.io import read_yaml, write_json, write_jsonl
from rou_transqa.metrics import qa_metrics
from rou_transqa.utils import set_global_seed


INSTRUCTION = (
    "Return exactly one contiguous verbatim span from the context. "
    "If the requested clause is absent, return exactly NO_ANSWER."
)


def prompt(question: str, context: str) -> str:
    return f"Instruction: {INSTRUCTION}\nQuestion: {question}\nContext: {context}\nAnswer:"


def context_windows(tokenizer, context: str, maximum: int, stride: int) -> list[str]:
    token_ids = tokenizer(context, add_special_tokens=False)["input_ids"]
    if len(token_ids) <= maximum:
        return [context]
    windows = []
    step = maximum - stride
    for start in range(0, len(token_ids), step):
        window_ids = token_ids[start : start + maximum]
        windows.append(tokenizer.decode(window_ids, skip_special_tokens=True))
        if start + maximum >= len(token_ids):
            break
    return windows


def training_rows(records: list[QARecord], tokenizer, maximum: int, stride: int) -> list[dict]:
    rows = []
    for record in records:
        for context in context_windows(tokenizer, record.context, maximum, stride):
            target = "NO_ANSWER"
            for gold in record.answers:
                if gold and gold in context:
                    target = gold
                    break
            rows.append({"prompt": prompt(record.question, context), "target": target})
    return rows


def tokenize_training(rows: list[dict], tokenizer, maximum: int):
    from datasets import Dataset

    def encode(row: dict) -> dict:
        prefix = tokenizer(row["prompt"], add_special_tokens=False)["input_ids"]
        target = tokenizer(" " + row["target"] + tokenizer.eos_token, add_special_tokens=False)["input_ids"]
        input_ids = (prefix + target)[-maximum:]
        prefix_width = max(0, len(input_ids) - len(target))
        labels = [-100] * prefix_width + input_ids[prefix_width:]
        return {"input_ids": input_ids, "attention_mask": [1] * len(input_ids), "labels": labels}

    return Dataset.from_list(rows).map(encode, remove_columns=["prompt", "target"])


def fit_model(model_name: str, tokenizer, records: list[QARecord], settings: dict, output_dir: Path):
    import torch
    from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
    from transformers import (
        AutoModelForCausalLM,
        BitsAndBytesConfig,
        DataCollatorForSeq2Seq,
        Trainer,
        TrainingArguments,
    )

    quantization = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type=settings["quantization_type"],
        bnb_4bit_use_double_quant=bool(settings["use_double_quant"]),
        bnb_4bit_compute_dtype=torch.bfloat16,
    )
    model = AutoModelForCausalLM.from_pretrained(model_name, quantization_config=quantization, device_map="auto")
    model = prepare_model_for_kbit_training(model)
    lora = LoraConfig(
        r=int(settings["lora_rank"]),
        lora_alpha=int(settings["lora_alpha"]),
        lora_dropout=float(settings["lora_dropout"]),
        bias="none",
        task_type="CAUSAL_LM",
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj"],
    )
    model = get_peft_model(model, lora)
    rows = training_rows(
        records,
        tokenizer,
        int(settings["max_sequence_length"]) - int(settings["max_new_tokens"]) - 256,
        int(settings["context_stride"]),
    )
    dataset = tokenize_training(rows, tokenizer, int(settings["max_sequence_length"]))
    per_device_batch = 1
    accumulation = max(1, int(settings["effective_batch_size"]) // per_device_batch)
    arguments = TrainingArguments(
        output_dir=str(output_dir / "trainer"),
        num_train_epochs=float(settings["epochs"]),
        learning_rate=float(settings["learning_rate"]),
        per_device_train_batch_size=per_device_batch,
        gradient_accumulation_steps=accumulation,
        logging_steps=50,
        save_strategy="epoch",
        report_to=[],
        bf16=True,
        seed=42,
    )
    trainer = Trainer(
        model=model,
        args=arguments,
        train_dataset=dataset,
        data_collator=DataCollatorForSeq2Seq(tokenizer, padding=True),
    )
    trainer.train()
    model.save_pretrained(output_dir / "adapter")
    tokenizer.save_pretrained(output_dir / "adapter")
    return model


def clean_generation(text: str, context: str) -> str:
    answer = text.strip().splitlines()[0].strip() if text.strip() else ""
    if answer == "NO_ANSWER":
        return ""
    return answer if answer and answer in context else ""


def evaluate_model(model, tokenizer, records: list[QARecord], settings: dict) -> list[dict]:
    import torch

    model.eval()
    output = []
    context_limit = int(settings["max_sequence_length"]) - int(settings["max_new_tokens"]) - 256
    for record in records:
        retained = []
        for context in context_windows(tokenizer, record.context, context_limit, int(settings["context_stride"])):
            encoded = tokenizer(
                prompt(record.question, context),
                return_tensors="pt",
                truncation=True,
                max_length=int(settings["max_sequence_length"]) - int(settings["max_new_tokens"]),
            ).to(model.device)
            with torch.no_grad():
                generated = model.generate(
                    **encoded,
                    max_new_tokens=int(settings["max_new_tokens"]),
                    do_sample=False,
                    num_beams=1,
                    pad_token_id=tokenizer.eos_token_id,
                )
            suffix = generated[0][encoded["input_ids"].shape[1] :]
            decoded = tokenizer.decode(suffix, skip_special_tokens=True)
            retained.append(clean_generation(decoded, context))
        valid = [value for value in retained if value]
        prediction = max(valid, key=len) if valid else ""
        output.append(
            {
                "qa_id": record.qa_id,
                "prediction": prediction,
                "candidate_prediction": prediction,
                "answerability_probability": float(bool(prediction)),
                "answerability_logit": 20.0 if prediction else -20.0,
                "gold_answers": list(record.answers),
            }
        )
    return output


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--mode", choices=["train", "evaluate", "all"], default="all")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    set_global_seed(args.seed)
    config = read_yaml(args.config)
    if args.model not in config["decoder_models"]:
        raise KeyError(f"Unknown decoder baseline: {args.model}")
    base = read_yaml(ROOT / config["base_config"])
    model_name = config["decoder_models"][args.model]["identifier"]
    settings = config["decoder_training"]
    try:
        from transformers import AutoModelForCausalLM, AutoTokenizer
        from peft import PeftModel
    except ImportError as error:
        raise RuntimeError("Install the decoder dependencies before this command") from error
    tokenizer = AutoTokenizer.from_pretrained(model_name, use_fast=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    manifest = ROOT / base["data"]["manifest_dir"] / "contract_manifest.csv"
    with manifest.open("r", encoding="utf-8") as handle:
        assignment = {row["contract_id"]: row["split"] for row in csv.DictReader(handle)}
    records = load_cuad(
        base["data"]["dataset_id"], base["data"]["dataset_revision"], base["data"]["cache_dir"]
    )
    split = split_records(records, assignment)
    output_dir = ROOT / "outputs" / "decoders" / args.model / f"seed_{args.seed}"
    output_dir.mkdir(parents=True, exist_ok=True)
    model = None
    if args.mode in {"train", "all"}:
        model = fit_model(model_name, tokenizer, split["train"], settings, output_dir)
    if args.mode in {"evaluate", "all"}:
        if model is None:
            base_model = AutoModelForCausalLM.from_pretrained(model_name, device_map="auto")
            model = PeftModel.from_pretrained(base_model, output_dir / "adapter")
        predictions = evaluate_model(model, tokenizer, split["test"], settings)
        metrics = qa_metrics(predictions)
        write_jsonl(output_dir / "test_predictions.jsonl", predictions)
        write_json(output_dir / "test_metrics.json", metrics)
        print(metrics)


if __name__ == "__main__":
    main()

