#!/usr/bin/env python3
from __future__ import annotations

import json
import re
from pathlib import Path

from _path import add_src

ROOT = add_src()

from rou_transqa.io import read_json, read_yaml


TEXT_SUFFIXES = {".md", ".py", ".yaml", ".yml", ".json", ".csv", ".txt", ".toml", ".sh", ""}
REQUIRED = [
    "README.md",
    "requirements.txt",
    "environment.yml",
    "configs/main.yaml",
    "scripts/train.py",
    "scripts/evaluate.py",
    "scripts/evaluate_external.py",
    "src/rou_transqa/model.py",
    "src/rou_transqa/mapping.py",
    "reproducibility/RESULT_PROVENANCE.md",
    "reproducibility/schema/external_validation.schema.json",
]


def plain_text_files() -> list[Path]:
    return [path for path in ROOT.rglob("*") if path.is_file() and path.suffix.lower() in TEXT_SUFFIXES]


def main() -> None:
    failures: list[str] = []
    for relative in REQUIRED:
        if not (ROOT / relative).is_file():
            failures.append(f"missing:{relative}")

    config = read_yaml(ROOT / "configs" / "main.yaml")
    required_config = {
        "model": ["encoder", "max_length", "stride", "answerability_loss_weight"],
        "training": ["learning_rate", "batch_size", "epochs", "seeds"],
        "inference": ["threshold", "threshold_grid", "no_answer_f1_floor"],
        "statistics": ["paired_bootstrap_resamples", "multiple_test_correction"],
    }
    for section, keys in required_config.items():
        for key in keys:
            if key not in config.get(section, {}):
                failures.append(f"config:{section}.{key}")

    blocked_words = ["exam" + "ple", "exam" + "ples", "t" + "oy", "illustr" + "ative", "模" + "拟"]
    identity_patterns = [
        re.compile(r"[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}", re.IGNORECASE),
        re.compile(r"(?:/" + "home" + r"/|/" + "Users" + r"/|C:\\\\" + "Users" + r"\\\\)"),
    ]
    for path in plain_text_files():
        text = path.read_text(encoding="utf-8", errors="ignore")
        lowered = text.lower()
        for word in blocked_words:
            if word.lower() in lowered:
                failures.append(f"blocked_word:{path.relative_to(ROOT)}:{word}")
        for pattern in identity_patterns:
            if pattern.search(text):
                failures.append(f"identity_pattern:{path.relative_to(ROOT)}")

    raw_files = [path for path in (ROOT / "data" / "raw").rglob("*") if path.is_file() and path.name != ".gitkeep"]
    if raw_files:
        failures.append("raw_data_present")

    summary = read_json(ROOT / "records" / "manuscript_reported" / "summary.json")
    if summary.get("provenance") != "manuscript_reported":
        failures.append("summary_provenance")
    for csv_path in (ROOT / "records" / "manuscript_reported").glob("*.csv"):
        first_line = csv_path.read_text(encoding="utf-8").splitlines()[0]
        if not first_line.startswith("provenance,"):
            failures.append(f"csv_provenance:{csv_path.name}")

    result = {
        "status": "passed" if not failures else "failed",
        "checked_files": len(plain_text_files()),
        "failures": failures,
    }
    print(json.dumps(result, indent=2, sort_keys=True))
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
