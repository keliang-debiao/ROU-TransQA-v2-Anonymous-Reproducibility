#!/usr/bin/env python3
from __future__ import annotations

import argparse
import subprocess
import sys

import yaml

from _path import add_src

ROOT = add_src()

from rou_transqa.io import read_yaml


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--variant", action="append")
    args = parser.parse_args()
    ablation = read_yaml(args.config)
    base = read_yaml(ROOT / ablation["base_config"])
    selected_variants = args.variant or list(ablation["variants"])
    for name in selected_variants:
        settings = ablation["variants"][name]
        config = read_yaml(ROOT / ablation["base_config"])
        config["project"]["output_root"] = f"outputs/ablations/{name}"
        config["model"]["use_answerability_head"] = bool(settings["use_answerability_head"])
        config["model"]["conditional_span_masking"] = bool(settings["conditional_span_masking"])
        config["model"]["dynamic_penalty_weight"] = 0.1 if settings["dynamic_penalty"] else 0.0
        config["model"]["answerability_loss_weight"] = float(
            settings.get("answerability_loss_weight", base["model"]["answerability_loss_weight"])
        )
        generated = ROOT / "outputs" / "ablations" / name / "frozen_config.yaml"
        generated.parent.mkdir(parents=True, exist_ok=True)
        with generated.open("w", encoding="utf-8") as handle:
            yaml.safe_dump(config, handle, sort_keys=False)
        subprocess.run(
            [sys.executable, str(ROOT / "scripts" / "train.py"), "--config", str(generated), "--seed", str(args.seed)],
            check=True,
            cwd=ROOT,
        )
        checkpoint = ROOT / config["project"]["output_root"] / f"seed_{args.seed}" / "best"
        subprocess.run(
            [
                sys.executable,
                str(ROOT / "scripts" / "evaluate.py"),
                "--config",
                str(generated),
                "--checkpoint",
                str(checkpoint),
                "--split",
                "test",
            ],
            check=True,
            cwd=ROOT,
        )


if __name__ == "__main__":
    main()

