#!/usr/bin/env python3
from __future__ import annotations

import argparse

import numpy as np

from _path import add_src

add_src()

from rou_transqa.calibration import (
    binary_nll,
    brier_score,
    expected_calibration_error,
    fit_temperature,
    sigmoid,
)
from rou_transqa.io import read_jsonl, write_json
from rou_transqa.metrics import normalize_answer


def arrays(rows: list[dict]) -> tuple[np.ndarray, np.ndarray]:
    logits = np.asarray([float(row["answerability_logit"]) for row in rows], dtype=float)
    labels = np.asarray(
        [int(any(normalize_answer(str(value)) for value in row.get("gold_answers", [""]))) for row in rows],
        dtype=int,
    )
    return logits, labels


def scores(logits: np.ndarray, labels: np.ndarray, temperature: float, bins: int = 15) -> dict:
    probabilities = sigmoid(logits / temperature)
    return {
        "nll": binary_nll(logits, labels, temperature),
        "brier": brier_score(probabilities, labels),
        "ece": expected_calibration_error(probabilities, labels, bins),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--validation", required=True)
    parser.add_argument("--test", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--bins", type=int, default=15)
    args = parser.parse_args()
    validation_logits, validation_labels = arrays(read_jsonl(args.validation))
    test_logits, test_labels = arrays(read_jsonl(args.test))
    temperature = fit_temperature(validation_logits, validation_labels)
    result = {
        "fit_split": "validation",
        "temperature": temperature,
        "validation_before": scores(validation_logits, validation_labels, 1.0, args.bins),
        "validation_after": scores(validation_logits, validation_labels, temperature, args.bins),
        "test_before": scores(test_logits, test_labels, 1.0, args.bins),
        "test_after": scores(test_logits, test_labels, temperature, args.bins),
    }
    write_json(args.output, result)
    print(result)


if __name__ == "__main__":
    main()

