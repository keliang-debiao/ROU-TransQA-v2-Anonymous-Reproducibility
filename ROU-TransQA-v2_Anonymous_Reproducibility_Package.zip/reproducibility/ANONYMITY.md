# Anonymous-review safeguards

This archive contains no author name, institutional affiliation, email address, grant identifier, repository-owner name, private URL, access token, or absolute workstation path.

The repository title and software package name describe the method only. Public datasets and public model identifiers are named because they are required for technical reproduction. Enterprise records are not distributed. De-identified external records can be supplied by the authors only when confidentiality permits.

