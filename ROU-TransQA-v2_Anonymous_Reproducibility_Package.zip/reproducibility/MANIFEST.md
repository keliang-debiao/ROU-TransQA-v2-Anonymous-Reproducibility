# Reproducibility manifest

| Manuscript component | Repository entry point | Primary artifact |
|---|---|---|
| Contract-grouped CUAD split | `scripts/prepare_cuad.py` | split manifests |
| ROU-TransQA-v2 training | `scripts/train.py` | checkpoint and JSONL history |
| Joint inference | `scripts/evaluate.py` | prediction JSONL and metrics JSON |
| Validation threshold | `scripts/tune_threshold.py` | threshold selection JSON |
| Temperature scaling | `scripts/calibrate.py` | calibration JSON |
| Five-seed robustness | `scripts/run_five_seeds.sh`, `scripts/aggregate_seeds.py` | summary JSON |
| Component ablation | `scripts/run_ablation.py` | variant metrics JSON |
| Encoder baselines | `scripts/run_encoder_baseline.py` | per-model outputs |
| Decoder baselines | `scripts/run_decoder_baseline.py` | constrained outputs |
| Paired inference tests | `scripts/paired_bootstrap.py` | interval and p-value JSON |
| D1-D6 mapping | `scripts/run_mapping.py` | indicator CSV |
| IFRS 16 associations | `scripts/analyze_disclosure.py` | association CSV and figures |
| External validation | `scripts/evaluate_external.py` | subset and overall metrics |
| Manuscript figure regeneration | `scripts/generate_figures.py` | PNG and PDF figures |
| Integrity verification | `scripts/verify_repository.py` | verification log |

