# Result provenance

The archive separates three result classes:

1. `records/manuscript_reported/` contains values transcribed from the associated manuscript. Files in this directory use the provenance value `manuscript_reported` or state the same origin in their header.
2. `logs/verification/` contains records generated while checking this software archive on deterministic fixtures. These logs establish function-level behavior and repository integrity only.
3. `outputs/` is initially empty and receives newly computed training, validation, test, calibration, mapping, and statistical outputs.

No manuscript-reported metric is represented as a newly executed model result. A full rerun requires the declared software environment, public datasets, model weights, and stated hardware. External enterprise results additionally require authorized access to the de-identified validation file.

